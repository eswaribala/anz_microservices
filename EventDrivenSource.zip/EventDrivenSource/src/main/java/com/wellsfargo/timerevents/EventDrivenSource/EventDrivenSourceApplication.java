package com.wellsfargo.timerevents.EventDrivenSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventDrivenSourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventDrivenSourceApplication.class, args);
	}
}
