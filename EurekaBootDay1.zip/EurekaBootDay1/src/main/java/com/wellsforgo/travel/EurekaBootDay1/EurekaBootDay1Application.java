package com.wellsforgo.travel.EurekaBootDay1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaBootDay1Application {

	public static void main(String[] args) {
		SpringApplication.run(EurekaBootDay1Application.class, args);
	}
}
