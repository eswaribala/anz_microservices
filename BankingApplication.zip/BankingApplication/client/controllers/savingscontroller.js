/**
 * Created by BALASUBRAMANIAM on 28/08/2017.
 */
savingsModule.controller('SavingsCtlr',['$scope',function($scope)
{
    $scope.account={
        accountId:0,
        balance:0,
        type:'savings'
    }


}]);