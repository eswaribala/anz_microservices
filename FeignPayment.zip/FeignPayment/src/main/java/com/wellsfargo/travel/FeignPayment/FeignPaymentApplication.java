package com.wellsfargo.travel.FeignPayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeignPaymentApplication.class, args);
	}
}
