/**
 * Created by BALASUBRAMANIAM on 07/09/2017.
 */
var customerApp=angular.module('CustomerApp',['UserApp']);