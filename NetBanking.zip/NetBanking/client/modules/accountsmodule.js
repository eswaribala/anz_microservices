/**
 * Created by BALASUBRAMANIAM on 07/09/2017.
 */
var accountsApp=angular.module('AccountsApp',['CustomerApp']);