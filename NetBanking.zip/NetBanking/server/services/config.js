/**
 * Created by BALASUBRAMANIAM on 06/09/2017.
 */
exports.apiport=10000;