/**
 * Created by BALASUBRAMANIAM on 07/09/2017.
 */
var connRef=require('./connectionHelper')
var customerModelRef=require('./dbschema').CustomerModel;
var accountModelRef=require('./dbschema').AccountModel;
module.exports.addData=function(obj)
{

    Id=parseInt(obj.customerRef);
    customerModelRef.findOne({customerId:Id},function(err,res){
        console.log(res);
        obj=new  accountModelRef({
            accountNo:obj.accountNo,
            accountType:obj.accountType,
            balance:obj.balance,
            customerRef:res

        })

         obj.save(function(err,success)
         {
         if(!err)
         console.log("Saved!!!");
         });


    });




}