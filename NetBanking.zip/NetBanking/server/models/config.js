/**
 * Created by BALASUBRAMANIAM on 06/09/2017.
 */
exports.url='127.0.0.1'
exports.mongodb='netbankingdb'
exports.mongoport=27017