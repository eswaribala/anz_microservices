angular.module('JWTDemoApp')
// Creating the Angular Controller
.controller('AccessDeniedController', function($http, $scope, AuthService) {
});
